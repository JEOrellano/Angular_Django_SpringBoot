package com.example.demo.domain;

public enum Estado {
    Aceptada, Rechazada, Pendiente
}
